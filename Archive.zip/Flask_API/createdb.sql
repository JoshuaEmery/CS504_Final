-- Drop the existing tables if they exist
DROP TABLE IF EXISTS user_logins;
DROP TABLE IF EXISTS users;

-- Create the users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(45),
    email VARCHAR(45),
    failed_login_count INT(10) DEFAULT 0 NOT NULL,
    locked_out TINYINT(3) DEFAULT 0 NOT NULL,
    locked_out_end DATETIME,
    email_to_upper VARCHAR(45),
    password_hash VARCHAR(255),
    failed_login_time DATETIME
);

-- Create the user_logins table
CREATE TABLE user_logins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    logged_in DATETIME,
    successful TINYINT(3),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Insert three users into the users table for testing
INSERT INTO users (id, username, email, locked_out_end, email_to_upper, password_hash)
VALUES
    (1, 'user1', 'user1@example.com', NULL, 'USER1@EXAMPLE.COM', 'password1'),
    (2, 'user2', 'user2@example.com', NULL, 'USER2@EXAMPLE.COM', 'password2'),
    (3, 'user3', 'user3@example.com', NULL, 'USER3@EXAMPLE.COM', 'password3');
    
-- Add the user account used by the API. This account cannot delete records
-- or create new SQL accounts
CREATE USER api_account IDENTIFIED BY 'CS504Passw3rd!123';
GRANT SELECT, INSERT, UPDATE ON users_db.* TO api_account;
