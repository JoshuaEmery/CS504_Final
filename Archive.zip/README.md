# CS504_Final

## Instructions for launching this API

## Clone this repository.

## Optional (create a virual environment to install the packges)

## run pip install -r requirements.txt

## manually copy the dbSecrets.py file into the same folder as app.py (not included, this file is in the teams chat)

- This file contains login information for the database and so is not included in github

## launch a MySQL instance in docker or through any other method

- Run the createdb.sql file to generate the database on your MySQL instance

## run the flask app with either python app.py or flask run

## navigate to http://127.0.0.1:8080 to verify the API is working

## navigate to http://127.0.0.1:8080/users to verify the database is working
